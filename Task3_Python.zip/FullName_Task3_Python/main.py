# Task 3: Test all 15 functions imported from solutions.py

from solutions import (
    word_frequency, character_frequency, first_non_repeating_character,
    are_anagrams, first_repeating_character, move_zeros_to_end,
    second_highest_distinct, remove_duplicates, missing_number,
    two_sum_first_pair, closest_to_zero, common_elements, rotate_right,
    max_consecutive_pair_sum, all_unique_pairs
)

def show(question, function, test_cases):
    print(f"\n{question}")
    for args in test_cases:
        print(f"Input: {args} -> Output: {function(*args)}")

show("Q1", word_frequency, [
    ("python is easy and python is powerful",),
    ("hello hello world",)
])
show("Q2", character_frequency, [
    ("banana",),
    ("book",)
])
show("Q3", first_non_repeating_character, [
    ("swiss",),
    ("aabb",)
])
show("Q4", are_anagrams, [
    ("listen", "silent"),
    ("hello", "world")
])
show("Q5", first_repeating_character, [
    ("programming",),
    ("abcde",)
])
show("Q6", move_zeros_to_end, [
    ([0, 3, 0, 1, 2, 0, 4],),
    ([1, 2, 3],)
])
show("Q7", second_highest_distinct, [
    ([10, 20, 40, 30, 40, 20],),
    ([5, 5, 5],)
])
show("Q8", remove_duplicates, [
    ([4, 2, 4, 5, 2, 7, 5],),
    ([1, 1, 2, 3, 2],)
])
show("Q9", missing_number, [
    ([1, 2, 4, 5, 6], 6),
    ([1, 3, 4], 4)
])
show("Q10", two_sum_first_pair, [
    ([2, 7, 11, 15], 9),
    ([1, 2, 3], 20)
])
show("Q11", closest_to_zero, [
    ([-8, -3, 2, 5, -2],),
    ([-4, -1, 1, 7],)
])
show("Q12", common_elements, [
    ([1, 2, 3, 4, 5], [3, 4, 5, 6, 7]),
    ([1, 1, 2, 3], [3, 1, 1])
])
show("Q13", rotate_right, [
    ([1, 2, 3, 4, 5], 2),
    ([1, 2, 3], 0)
])
show("Q14", max_consecutive_pair_sum, [
    ([4, 7, 2, 9, 5],),
    ([-2, -3, -1],)
])
show("Q15", all_unique_pairs, [
    ([2, 4, 3, 5, 7, 8, 1], 9),
    ([1, 1, 2, 3, 4], 5)
])
