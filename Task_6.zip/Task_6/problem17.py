# Problem 17: Check Strict Superset
# HackerRank: https://www.hackerrank.com/challenges/py-check-strict-superset/problem

a = set(input().split())
n = int(input())

is_strict_superset = True
for _ in range(n):
    other = set(input().split())
    if not a > other:
        is_strict_superset = False
        break

print(is_strict_superset)
