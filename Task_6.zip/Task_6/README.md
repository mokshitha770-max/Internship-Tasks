# Python Task 06 – HackerRank Coding Practice

Contains 20 Python solutions in the required order.

- Files: `problem1.py` through `problem20.py`
- Each file includes the problem name and HackerRank link at the top.
- Copy/paste each solution into the matching HackerRank challenge and submit it there.
- These are reference solutions; test each on HackerRank before submitting.

