# Problem 16: Check Subset
# HackerRank: https://www.hackerrank.com/challenges/py-check-subset/problem

t = int(input())

for _ in range(t):
    n_a = int(input())
    a = set(input().split())
    n_b = int(input())
    b = set(input().split())

    print(a.issubset(b))
